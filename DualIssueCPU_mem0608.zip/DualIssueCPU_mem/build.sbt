// build.sbt
name := "DualIssueCPU"
version := "0.1.0"

scalaVersion := "2.12.15"

addCompilerPlugin("edu.berkeley.cs" % "chisel3-plugin" % "3.5.4" cross CrossVersion.full)

libraryDependencies ++= Seq(
  "edu.berkeley.cs" %% "chisel3"     % "3.5.4",
  "edu.berkeley.cs" %% "chiseltest"  % "0.5.4" % Test
)

scalacOptions ++= Seq("-feature", "-encoding", "utf8")
