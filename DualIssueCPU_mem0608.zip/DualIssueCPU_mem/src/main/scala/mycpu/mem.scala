// package mycpu

// import chisel3._
// import chisel3.util._

// // 指令存储器，存储深度为memDepth，按字节存储，每条指令4字节小端存储
// class InstROM(memDepth: Int) extends Module {
//   val io = IO(new Bundle {
//     val addr = Input(UInt(log2Ceil(memDepth).W))
//     val inst = Output(Vec(4, UInt(8.W)))  // 每条指令4字节
//   })

//   val rom = VecInit(Seq(
//    VecInit(Seq("h93", "h00", "hC0", "h3B").map(_.U(8.W))), // 0x3BC00093 -> addi x1, x0, 3BC
//   VecInit(Seq("h13", "h01", "h40", "h01").map(_.U(8.W))), // 0x01400113 -> addi x2, x0, 20
//   VecInit(Seq("hB3", "h81", "h20", "h00").map(_.U(8.W))), // 0x002081b3 -> add  x3, x1, x2
//   VecInit(Seq("h33", "h02", "h11", "h40").map(_.U(8.W))), // 0x40110233 -> sub  x4, x2, x1
//   VecInit(Seq("hB3", "h82", "h20", "h02").map(_.U(8.W))), // 0x022082b3 -> mul  x5, x1, x2
//   VecInit(Seq("h33", "h43", "h11", "h02").map(_.U(8.W))), // 0x02114333 -> div  x6, x2, x1
//   VecInit(Seq("hB3", "h63", "h11", "h02").map(_.U(8.W))), // 0x021163b3 -> rem  x7, x2, x1
//   VecInit(Seq("h33", "h94", "h20", "h00").map(_.U(8.W))), // 0x00209433 -> sll  x8, x1, x2
//   VecInit(Seq("h23", "h22", "h11", "h00").map(_.U(8.W))), // 0x00112223 -> sw x1, 4(x2)
//   VecInit(Seq("hB3", "h85", "h20", "h00").map(_.U(8.W))), // 0x002085b3 -> add x11, x1, x2
//   VecInit(Seq("h83", "h21", "h41", "h00").map(_.U(8.W))), // 0x00412183 -> lw x3, 4(x2)
//   VecInit(Seq("h93", "h00", "h40", "h01").map(_.U(8.W)))  // 0x01400093 -> addi x1, x0, 20

// ) ++ Seq.fill(memDepth - 8)(VecInit(Seq.fill(4)(0.U(8.W)))))

//   io.inst := rom(io.addr)
// }

// class if_mem extends Bundle {
//   val instAddr = Output(UInt(64.W)) // 这里假设是字节地址
// }

// class mem_id(val instWidth: Int) extends Bundle {
//   val inst = Output(Vec(instWidth, UInt(32.W)))  // 多条指令
// }

// class lsu_mem_c extends Bundle {
//   val atomFlag  = Output(Bool())
//   val dataAddr  = Output(UInt(64.W))
//   val writeEn   = Output(Bool())
//   val writeData = Output(UInt(64.W))
//   val func3     = Output(UInt(3.W))
// }

// class mem_lsu_c extends Bundle {
//   val data = Output(UInt(64.W))
// }

// class mem(memDepth: Int, instWidth: Int) extends Module {
//   val io = IO(new Bundle {
//     val if_mem  = Flipped(new if_mem())
//     val ex_mem  = Flipped(new lsu_mem_c)
//     val mem_id  = new mem_id(instWidth)
//     val mem_lsu = new mem_lsu_c
//   })

//   val memInside = SyncReadMem(memDepth, Vec(4, UInt(8.W)))

//   // 多路InstROM实现双发射
//   val instRoms = Seq.fill(instWidth)(Module(new InstROM(memDepth)))

//   for (i <- 0 until instWidth) {
//     // instAddr是字节地址，右移2位得到指令地址，+ i 取对应指令
//     val baseAddr = (io.if_mem.instAddr >> 2)(log2Ceil(memDepth)-1, 0)
//     instRoms(i).io.addr := (baseAddr + i.U)(log2Ceil(memDepth)-1, 0)

//     // 小端拼接字节，低地址字节低位
//     val instBytes = instRoms(i).io.inst
//     val instWord = Cat(instBytes(3), instBytes(2), instBytes(1), instBytes(0))

//     // 重置时默认输出NOP指令 addi x0,x0,0 = 0x00000013
//     io.mem_id.inst(i) := Mux(reset.asBool(), "h00000013".U(32.W), instWord)
//   }

//   // 以下数据内存读写逻辑保持不变，代码略去（和原先一样）

//   // .... 这里保留您原有的mem写入和读取代码

//   // 由于篇幅限制，完整的写入和读取代码不变，保持原有实现

//   // 例如
//   val memWriteVec  = Wire(Vec(4, UInt(8.W)))
//   val memWriteVec1 = Wire(Vec(4, UInt(8.W)))
//   for (i <- 0 to 3) {
//     memWriteVec(i)  := io.ex_mem.writeData(i * 8 + 7, i * 8)
//     memWriteVec1(i) := io.ex_mem.writeData((i + 4) * 8 + 7, (i + 4) * 8)
//   }

//   // ... 省略您的mem写入选择逻辑和数据拼接 ...

//   val dataAddr   = Wire(UInt(64.W))
//   val dataAddrP1 = Wire(UInt(64.W))
//   val dataAddrP2 = Wire(UInt(64.W))
//   dataAddr   := io.ex_mem.dataAddr >> 2.U
//   dataAddrP1 := dataAddr + 1.U
//   dataAddrP2 := dataAddr + 2.U

//   io.mem_lsu.data := Cat(
//     memInside.read(dataAddrP1).reduce(Cat(_, _)),
//     memInside.read(dataAddr).reduce(Cat(_, _))
//   )

//   // mem写入选择及写入逻辑
//   val memChoose0 = Wire(Vec(4, Bool()))
//   val memChoose1 = Wire(Vec(4, Bool()))
//   for (i <- 0 to 3) {
//     memChoose0(i) := false.B
//     memChoose1(i) := false.B
//   }

//   switch(io.ex_mem.func3) {
//     is(0.U) { // SB
//       memChoose0(io.ex_mem.dataAddr(1, 0)) := true.B
//     }
//     is(1.U) { // SH
//       when(io.ex_mem.dataAddr(1, 0) =/= 3.U) {
//         memChoose0(io.ex_mem.dataAddr(1, 0))       := true.B
//         memChoose0(io.ex_mem.dataAddr(1, 0) + 1.U) := true.B
//       }.otherwise {
//         memChoose0(3) := true.B
//         memChoose1(0) := true.B
//       }
//     }
//     is(2.U) { // SW
//       memChoose0(0) := io.ex_mem.dataAddr(1, 0) === 0.U
//       memChoose0(1) := io.ex_mem.dataAddr(1, 0) <= 1.U
//       memChoose0(2) := io.ex_mem.dataAddr(1, 0) <= 2.U
//       memChoose0(3) := io.ex_mem.dataAddr(1, 0) <= 3.U
//       memChoose1(0) := io.ex_mem.dataAddr(1, 0) >= 1.U
//       memChoose1(1) := io.ex_mem.dataAddr(1, 0) >= 2.U
//       memChoose1(2) := io.ex_mem.dataAddr(1, 0) >= 3.U
//     }
//     is(3.U) { // SD
//       memChoose0(0) := io.ex_mem.dataAddr(1, 0) === 0.U
//       memChoose0(1) := io.ex_mem.dataAddr(1, 0) <= 1.U
//       memChoose0(2) := io.ex_mem.dataAddr(1, 0) <= 2.U
//       memChoose0(3) := io.ex_mem.dataAddr(1, 0) <= 3.U
//       memChoose1(0) := io.ex_mem.dataAddr(1, 0) >= 1.U
//       memChoose1(1) := io.ex_mem.dataAddr(1, 0) >= 2.U
//       memChoose1(2) := io.ex_mem.dataAddr(1, 0) >= 3.U
//     }
//   }

//   when(io.ex_mem.writeEn) {
//     when(io.ex_mem.func3 === 3.U) {
//       memInside.write(dataAddr, memWriteVec, memChoose0)
//       memInside.write(dataAddrP1, memWriteVec, memChoose1)
//       memInside.write(dataAddrP1, memWriteVec1, memChoose0)
//       memInside.write(dataAddrP2, memWriteVec1, memChoose1)
//     }.otherwise {
//       memInside.write(dataAddr, memWriteVec, memChoose0)
//       memInside.write(dataAddrP1, memWriteVec, memChoose1)
//     }
//   }
// }









































// --- 文件: mem.scala (最终·修改版) ---

package mycpu

import chisel3._
import chisel3.util._
import chisel3.util.experimental.loadMemoryFromFile
import firrtl.annotations.MemoryLoadFileType

class if_mem extends Bundle {
  val instAddr = Output(UInt(64.W))
  val valid    = Output(Bool())
  val flush    = Output(Bool())
  val ready_for_pc = Input(Bool())
}

class mem_id(val instWidth: Int) extends Bundle {
  val inst  = Output(Vec(instWidth, UInt(32.W)))
  val valid = Output(Bool())
  val pc    = Output(UInt(64.W))
  val ready = Input(Bool())
}

// =============================================================================
// == 接口修改: 添加 is_load 信号
// =============================================================================
class lsu_mem_c extends Bundle {
  val atomFlag  = Output(Bool())
  val dataAddr  = Output(UInt(64.W))
  val writeEn   = Output(Bool())
  val writeData = Output(UInt(64.W))
  val func3     = Output(UInt(3.W))
  val is_load   = Output(Bool()) // << --- [关键修改] 新增信号，用于明确指示加载操作
}

class mem_lsu_c extends Bundle {
  val data = Output(UInt(64.W))
}


class mem(memDepth: Int, instWidth: Int) extends Module {
  val io = IO(new Bundle {
    val if_mem  = Flipped(new if_mem())
    val ex_mem  = Flipped(new lsu_mem_c)
    val mem_id  = new mem_id(instWidth)
    val mem_lsu = new mem_lsu_c
  })

  val memInside = SyncReadMem(memDepth, Vec(4, UInt(8.W)))


  // =============================================================================
  val debugData = Wire(Vec(4, UInt(8.W)))
  debugData := memInside.read(0x85A2.U)
  dontTouch(debugData)
  // =============================================================================


  // =============================================================================
  // == 指令读取逻辑 (Instruction Fetch) - 保持不变
  // =============================================================================

  val fetch_addr_reg = Reg(UInt(64.W))
  val s_idle :: s_wait :: s_valid :: Nil = Enum(3)
  val state = RegInit(s_idle)
  val has_just_reset = RegNext(reset.asBool, true.B)

  io.if_mem.ready_for_pc := false.B
  io.mem_id.valid := false.B
  io.mem_id.pc    := fetch_addr_reg

  switch(state) {
    is(s_idle) {
      io.if_mem.ready_for_pc := !has_just_reset
      when(io.if_mem.valid) {
        fetch_addr_reg := io.if_mem.instAddr
        state := s_wait
      }
    }
    is(s_wait) {
      io.if_mem.ready_for_pc := false.B
      io.mem_id.valid := false.B
      state := s_valid
    }
    is(s_valid) {
      io.if_mem.ready_for_pc := false.B
      io.mem_id.valid := true.B
      when(io.mem_id.ready) {
        state := s_idle
      }
    }
  }

  when(io.if_mem.flush) {
    state := s_idle
  }

  for (i <- 0 until instWidth) {
    val readAddress = (fetch_addr_reg >> 2.U) + i.U
    val readDataVec = memInside.read(readAddress)
    io.mem_id.inst(i) := Cat(readDataVec(3), readDataVec(2), readDataVec(1), readDataVec(0))
  }

  // =============================================================================
  // == 数据读取逻辑 (Data Load) - 【重要修改】
  // =============================================================================
  val dataReadAddr   = io.ex_mem.dataAddr >> 2.U 
  val dataReadAddrP1 = dataReadAddr + 1.U

  // --- [关键修改] 将无条件的并行读改为有条件的读 ---
  // 1. 先将加载数据的容器定义为Wire，并提供默认值以防生成意料之外的锁存器
  val loadedDataWord0 = Wire(Vec(4, UInt(8.W)))
  val loadedDataWord1 = Wire(Vec(4, UInt(8.W)))
  loadedDataWord0 := DontCare // Chisel推荐的做法
  loadedDataWord1 := DontCare

  // 2. 只有在LSU明确指示为加载指令时，才执行实际的内存读取操作
  when(io.ex_mem.is_load) {
    loadedDataWord0 := memInside.read(dataReadAddr)
    loadedDataWord1 := memInside.read(dataReadAddrP1)
  }

  // 3. 拼接逻辑保持不变，它现在使用条件读取后的Wire
  io.mem_lsu.data := Cat(
    loadedDataWord1(3), loadedDataWord1(2), loadedDataWord1(1), loadedDataWord1(0),
    loadedDataWord0(3), loadedDataWord0(2), loadedDataWord0(1), loadedDataWord0(0)
  )

  // =============================================================================
  // == 数据写入逻辑 (Data Store) - 保持不变, 其本身就是由 writeEn 条件保护的
  // =============================================================================
  val dataWriteAddr   = io.ex_mem.dataAddr >> 2.U
  val dataWriteAddrP1 = dataWriteAddr + 1.U
  val dataWriteAddrP2 = dataWriteAddr + 2.U
  val memWriteVec  = Wire(Vec(4, UInt(8.W)))
  val memWriteVec1 = Wire(Vec(4, UInt(8.W)))
  for (i <- 0 to 3) {
    memWriteVec(i)  := io.ex_mem.writeData(i * 8 + 7, i * 8)
    memWriteVec1(i) := io.ex_mem.writeData((i + 4) * 8 + 7, (i + 4) * 8)
  }
  switch(io.ex_mem.dataAddr(1, 0)) {
    is(1.U) {
      for (i <- 0 to 2) {
        memWriteVec(i + 1)  := io.ex_mem.writeData(i * 8 + 7, i * 8)
        memWriteVec1(i + 1) := io.ex_mem.writeData((i + 4) * 8 + 7, (i + 4) * 8)
      }
      for (i <- 0 to 0) {
        memWriteVec(i)  := io.ex_mem.writeData((i + 3) * 8 + 7, (i + 3) * 8)
        memWriteVec1(i) := io.ex_mem.writeData((i + 7) * 8 + 7, (i + 7) * 8)
      }
    }
    is(2.U) {
      for (i <- 0 to 1) {
        memWriteVec(i + 2)  := io.ex_mem.writeData(i * 8 + 7, i * 8)
        memWriteVec1(i + 2) := io.ex_mem.writeData((i + 4) * 8 + 7, (i + 4) * 8)
      }
      for (i <- 0 to 1) {
        memWriteVec(i)  := io.ex_mem.writeData((i + 2) * 8 + 7, (i + 2) * 8)
        memWriteVec1(i) := io.ex_mem.writeData((i + 6) * 8 + 7, (i + 6) * 8)
      }
    }
    is(3.U) {
      for (i <- 0 to 0) {
        memWriteVec(i + 3)  := io.ex_mem.writeData(i * 8 + 7, i * 8)
        memWriteVec1(i + 3) := io.ex_mem.writeData((i + 4) * 8 + 7, (i + 4) * 8)
      }
      for (i <- 0 to 2) {
        memWriteVec(i)  := io.ex_mem.writeData((i + 1) * 8 + 7, (i + 1) * 8)
        memWriteVec1(i) := io.ex_mem.writeData((i + 5) * 8 + 7, (i + 5) * 8)
      }
    }
  }
  val memChoose0 = Wire(Vec(4, Bool()))
  val memChoose1 = Wire(Vec(4, Bool()))
  for (i <- 0 to 3) {
    memChoose0(i) := false.B
    memChoose1(i) := false.B
  }
  switch(io.ex_mem.func3) {
    is(0.U) { memChoose0(io.ex_mem.dataAddr(1, 0)) := true.B }
    is(1.U) {
      when(io.ex_mem.dataAddr(1, 0) =/= 3.U) {
        memChoose0(io.ex_mem.dataAddr(1, 0))       := true.B
        memChoose0(io.ex_mem.dataAddr(1, 0) + 1.U) := true.B
      }.otherwise {
        memChoose0(3) := true.B
        memChoose1(0) := true.B
      }
    }
    is(2.U) {
      memChoose0(0) := Mux(io.ex_mem.dataAddr(1, 0) === 0.U, true.B, false.B)
      memChoose0(1) := Mux(io.ex_mem.dataAddr(1, 0) <= 1.U, true.B, false.B)
      memChoose0(2) := Mux(io.ex_mem.dataAddr(1, 0) <= 2.U, true.B, false.B)
      memChoose0(3) := Mux(io.ex_mem.dataAddr(1, 0) <= 3.U, true.B, false.B)
      memChoose1(0) := Mux(io.ex_mem.dataAddr(1, 0) >= 1.U, true.B, false.B)
      memChoose1(1) := Mux(io.ex_mem.dataAddr(1, 0) >= 2.U, true.B, false.B)
      memChoose1(2) := Mux(io.ex_mem.dataAddr(1, 0) >= 3.U, true.B, false.B)
    }
    is(3.U) {
      memChoose0(0) := Mux(io.ex_mem.dataAddr(1, 0) === 0.U, true.B, false.B)
      memChoose0(1) := Mux(io.ex_mem.dataAddr(1, 0) <= 1.U, true.B, false.B)
      memChoose0(2) := Mux(io.ex_mem.dataAddr(1, 0) <= 2.U, true.B, false.B)
      memChoose0(3) := Mux(io.ex_mem.dataAddr(1, 0) <= 3.U, true.B, false.B)
      memChoose1(0) := Mux(io.ex_mem.dataAddr(1, 0) >= 1.U, true.B, false.B)
      memChoose1(1) := Mux(io.ex_mem.dataAddr(1, 0) >= 2.U, true.B, false.B)
      memChoose1(2) := Mux(io.ex_mem.dataAddr(1, 0) >= 3.U, true.B, false.B)
    }
  }
  when(io.ex_mem.writeEn) {
    when(io.ex_mem.func3 === 3.U) {
      memInside.write(dataWriteAddr, memWriteVec, memChoose0)
      memInside.write(dataWriteAddrP1, memWriteVec, memChoose1)
      memInside.write(dataWriteAddrP1, memWriteVec1, memChoose0)
      memInside.write(dataWriteAddrP2, memWriteVec1, memChoose1)
    }.otherwise {
      memInside.write(dataWriteAddr, memWriteVec, memChoose0)
      memInside.write(dataWriteAddrP1, memWriteVec, memChoose1)
    }
  }

  // =============================================================================
  // == 初始化与调试 - 保持不变
  // =============================================================================
  loadMemoryFromFile(memInside, "/home/chisellab/Desktop/DualIssueCPU_mem/src/test/scala/dhrystone.data", MemoryLoadFileType.Hex)
  
  when(io.ex_mem.writeEn
    && io.ex_mem.dataAddr === "h10001ff1".U
    && io.ex_mem.func3 === 0.U) {
    printf("%c", io.ex_mem.writeData(7, 0))
  }
}