package mycpu

import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec

class TopArithMemDualIssueTest extends AnyFlatSpec with ChiselScalatestTester {
  behavior of "Top&Mem"

  it should "run dhrystone itself " in {

    test(new Top).withAnnotations(Seq(WriteVcdAnnotation)) { c =>
   //test(new Top) { c =>
      c.clock.setTimeout(200000) // 适当调整超时

      c.reset.poke(true.B)
      c.clock.step(10)
      c.reset.poke(false.B)
      c.clock.step(1000)
    }
  }
}