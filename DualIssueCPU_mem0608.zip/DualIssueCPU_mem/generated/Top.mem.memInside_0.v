module BindsTo_0_mem(
  input         clock,
  input         reset,
  input  [63:0] io_if_mem_instAddr,
  input         io_if_mem_valid,
  input         io_if_mem_flush,
  output        io_if_mem_ready_for_pc,
  input  [63:0] io_ex_mem_dataAddr,
  input         io_ex_mem_writeEn,
  input  [63:0] io_ex_mem_writeData,
  input  [2:0]  io_ex_mem_func3,
  input         io_ex_mem_is_load,
  output [31:0] io_mem_id_inst_0,
  output [31:0] io_mem_id_inst_1,
  output        io_mem_id_valid,
  output [63:0] io_mem_id_pc,
  input         io_mem_id_ready,
  output [63:0] io_mem_lsu_data
);

  
initial begin
  $readmemh("/home/chisellab/Desktop/DualIssueCPU_mem/src/test/scala/dhrystone_0.data", mem.memInside_0);
end
                      endmodule

bind mem BindsTo_0_mem BindsTo_0_mem_Inst(.*);